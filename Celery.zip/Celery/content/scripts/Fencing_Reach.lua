user = game.Players.LocalPlayer;
if user.Backpack:FindFirstChild("Foil") then
    user.Character.Humanoid:EquipTool(user.Backpack.Foil);
end
wait(1);
user.Character.Foil.Handle.Size=Vector3.new(1,1,30)
user.Character.Foil.Handle.Mesh.Scale=Vector3.new(1,1,6)
user.Character.Foil.Handle.Mesh.Offset=Vector3.new(0,0,6)
-- looks better with certain packages:
--user.Character.Foil.Handle.Mesh.Offset=Vector3.new(0.5,-0.5,6)
