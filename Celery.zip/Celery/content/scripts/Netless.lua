-- run this before running scripts that require a net bypass
-- credit to MiAiHsIs1226 I think
-- 
for i,v in next, game:GetService("Players").LocalPlayer.Character:GetDescendants() do
if v:IsA("BasePart") and v.Name ~="HumanoidRootPart" then 
game:GetService("RunService").Heartbeat:connect(function()
v.Velocity = Vector3.new(-25.6,0,0)
end)
game:GetService("RunService").Heartbeat:connect(function()
wait(.01)
v.Velocity = Vector3.new(0,0,0)
end)
end
end