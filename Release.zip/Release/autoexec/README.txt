Paste the script(s) you want to run first
into "autoexec.lua"

Whatever you do, dont change the filename from "autoexec.lua"
to anything else..

that is all (sorry, just one lua file is supported rn)
